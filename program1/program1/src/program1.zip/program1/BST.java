/*
 * Sarah Hall
 * CSCI 232
 * Program assignment 1
 */
package program1;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayDeque;
import java.util.Queue;
import java.util.Scanner;

public class BST {
	
	public Node root;
	
	public BST(){
		this.root = null;
	}
	
	public class Node{ //I just put the Node class inside of the BST tree because I'm lazy 
		int key; //key data whatever the value in the Node
		Node left; //the left child
		Node right;	//right child
		public Node(int key){ //constructor
			this.key = key; //initializing everything
			left = null;
			right = null;
		}
	}
	
	public void build() {
		try { //the try and catch thing to tell if the fiel is actually there
			@SuppressWarnings("resource")
				Scanner file = new Scanner(new File("input.txt")); //making a new file blah bal whatever
				while(file.hasNextLine()) { //while there's actually something IN the file we can do this shit
					String line = file.nextLine(); //I converted the file into a string because that makes it super easy to chop up all nice
					String words[] = line.split(",");//made an array for our strings hmhmhmhm
					for(int i = 0; i < words.length; i++) {//runnin through the array
						insert(Integer.parseInt(words[i]));
					}
				}
			}
			catch (FileNotFoundException e) { //boring shit
	            System.out.println("File not found");		
			}	
	}
	
	

	
	public boolean search(int id){
		Node current = root; //creating new Node called current, then setting it to root so we start 
							//our search at the top of the tree
		while(current!=null){ //keep the searching running only if there's anything in the tree
			if(current.key==id){ //cool found it nice
				System.out.println("Found");
				return true;
			}else if(current.key>id){ //if the current key is greater we need to move to the left
				current = current.left; //so now current is the node to the left
			}else{
				current = current.right; //otherwise we're going right
			}
		}
		System.out.println("The ID you are looking for does not exist");
		return false; //it's not there so 
	}
	
	
	public boolean delete(int id){ //this one is gnarly lmao.
		Node parent = root; //starting by making a parent Node which is equal to the root
		Node current = root; //also going to have a current that starts are the root
		boolean isLeftChild = false; 
		while(current.key!=id){  //loop through the tree when our current Node isn't the ID we wanna delete
			parent = current; //
			if(current.key>id){ //if our current is greater than our 
				isLeftChild = true;
				current = current.left;
			}else{
				isLeftChild = false;
				current = current.right;
			}
			if(current ==null){
				return false;
			}
		}
		//if i am here that means we have found the node
		//Case 1: if node to be deleted has no children
		if(current.left==null && current.right==null){
			if(current==root){
				root = null;
			}
			if(isLeftChild ==true){
				parent.left = null;
			}else{
				parent.right = null;
			}
		}
		//Case 2 : if node to be deleted has only one child
		else if(current.right==null){
			if(current==root){
				root = current.left;
			}else if(isLeftChild){
				parent.left = current.left;
			}else{
				parent.right = current.left;
			}
		}
		else if(current.left==null){
			if(current==root){
				root = current.right;
			}else if(isLeftChild){
				parent.left = current.right;
			}else{
				parent.right = current.right;
			}
		}else if(current.left!=null && current.right!=null){
			
			//now we have found the minimum element in the right sub tree
			Node successor	 = getSuccessor(current);
			if(current==root){
				root = successor;
			}else if(isLeftChild){
				parent.left = successor;
			}else{
				parent.right = successor;
			}			
			successor.left = current.left;
		}		
		System.out.println("The Node was deleted");
		printTree(root);
		return true;		
	}
	
	public Node getSuccessor(Node deleteNode){
		Node successsor =null;
		Node successsorParent =null;
		Node current = deleteNode.right;
		while(current!=null){
			successsorParent = successsor;
			successsor = current;
			current = current.left;
		}
		//check if successor has the right child, it cannot have left child for sure
		// if it does have the right child, add it to the left of successorParent.
//		successsorParent
		if(successsor!=deleteNode.right){
			successsorParent.left = successsor.right;
			successsor.right = deleteNode.right;
		}
		return successsor;
	}
	
	
	public void insert(int id){
		Node newNode = new Node(id);
		if(root==null){
			root = newNode;
			System.out.println("The Node was added");
			printTree(root);
			return;
		}
		Node current = root;
		Node parent = null;
		while(true){
			parent = current;
			if(id<current.key){				
				current = current.left;
				if(current==null){
					parent.left = newNode;
					System.out.println("The Node was added");
					printTree(root);
					return;
				}
			}else{
				current = current.right;
				if(current==null){
					parent.right = newNode;
					System.out.println("The Node was added");
					printTree(root);
					return;
				}
			}
		}
	}
	public void inOrder(Node root){
		if(root!=null){
			inOrder(root.left);
			System.out.print(" " + root.key);
			inOrder(root.right);
		}
	}
	
	public void postOrder(Node root){
		if(root!=null){
			postOrder(root.left);
			postOrder(root.right);
			System.out.print(" " + root.key);
		}
	}
	
	public void preOrder(Node root){
		if(root!=null){
			System.out.print(" " + root.key);
			preOrder(root.left);
			preOrder(root.right);
		}
	}
	
	public void printTree(Node root) {
	    if (root == null)
	        return;

	    Queue<Node> q = new ArrayDeque<>();

	    q.add(root);
	    do {
	        int size = q.size();
	        for (int i=0; i<size; i++) {
	            Node element = q.poll();
	            System.out.print("-" + element.key + "-");
	            if (element.left != null)
	                q.add(element.left);
	            if (element.right != null)
	                q.add(element.right);
	        }
	        System.out.println();
	    } while (q.size() > 0);
	}
}


